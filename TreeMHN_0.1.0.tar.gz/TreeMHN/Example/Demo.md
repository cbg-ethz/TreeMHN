1. Load require packages
========================

``` r
library(treeMHN)
library(corrplot)
```

    ## corrplot 0.84 loaded

``` r
# git clone https://github.com/RudiSchill/MHN
setwd("~/Documents/Projects/MHN-master/") # Use your own path
source("UtilityFunctions.R")
source("ModelConstruction.R")
```

    ## Loading required package: Matrix

``` r
source("Likelihood.R")
```

    ## Loading required package: inline

``` r
source("RegularizedOptimization.R")
```

2. Generate tree
================

``` r
n <- 10 # number of events
N <- 100 # number of samples
lambda_s <- 1 # sampling event rate
gamma <- 0.5 # penalty parameter
M <- 100 # number of samples for importance sampling
sparsity <- 0.5 # sparsity of the MHN
# generate non-empty trees
res <- generate_nonempty_trees(n = n, N = N, lambda_s = lambda_s, sparsity = sparsity)
true_Theta <- res$Theta # true MHN
trees <- res$trees # extract trees
#plot_tree(trees[[1]],res$mutations)
```

3. Learn MHN
============

``` r
# EM
pred_Theta_EM <- learn_MHN_EM(n, N, trees, gamma = gamma, lambda_s = lambda_s)
```

    ## Round:  0 
    ## log-likelihood:  -10215.68 
    ## Round:  1 
    ## log-likelihood:  -10215.67

``` r
# MCEM
pred_Theta_MCEM <- learn_MHN_MCEM(n, N, trees, gamma = gamma, lambda_s = lambda_s, M = M)
```

    ## Round:  0 
    ## log-likelihood:  -10215.68 
    ## Round:  1 
    ## log-likelihood:  -10215.67

``` r
# genotype
genotypes <- c()
for (i in c(1:length(trees))) {
  genotypes <- rbind(genotypes, trees[[i]]$genotypes)
}
pD <- Data.to.pD(genotypes)
pred_Theta_genotype <- Learn.MHN(pD, lambda = 1/(5*N))
```

4. Performance assessment
=========================

``` r
compare_Theta(true_Theta, pred_Theta_EM)
```

    ##       SHD        TP        FP        TN        FN Precision       TPR     FPR_N 
    ##     12.00     41.00      8.00     37.00      4.00      0.84      0.91      0.18 
    ##     FPR_P       MSE 
    ##      0.18      0.18

``` r
compare_Theta(true_Theta, pred_Theta_MCEM)
```

    ##       SHD        TP        FP        TN        FN Precision       TPR     FPR_N 
    ##     12.00     41.00      8.00     37.00      4.00      0.84      0.91      0.18 
    ##     FPR_P       MSE 
    ##      0.18      0.18

``` r
compare_Theta(true_Theta, pred_Theta_genotype)
```

    ##       SHD        TP        FP        TN        FN Precision       TPR     FPR_N 
    ##     42.00     11.00      8.00     37.00     34.00      0.58      0.24      0.18 
    ##     FPR_P       MSE 
    ##      0.18      0.96

``` r
par(mfrow = c(2,2))
cl.lim.up <- max(max(true_Theta),max(pred_Theta_EM),max(pred_Theta_MCEM),max(pred_Theta_genotype))
cl.lim.lo <- min(min(true_Theta),min(pred_Theta_EM),min(pred_Theta_MCEM),min(pred_Theta_genotype))
corrplot(true_Theta, is.corr = FALSE, title = "True MHN",cl.lim = c(cl.lim.lo,cl.lim.up),mar=c(0,0,1,0))
corrplot(pred_Theta_EM, is.corr = FALSE, title = "EM",cl.lim = c(cl.lim.lo,cl.lim.up),mar=c(0,0,1,0))
corrplot(pred_Theta_MCEM, is.corr = FALSE, title = "MCEM",cl.lim = c(cl.lim.lo,cl.lim.up),mar=c(0,0,1,0))
corrplot(pred_Theta_genotype, is.corr = FALSE, title = "genotype",cl.lim = c(cl.lim.lo,cl.lim.up),mar=c(0,0,1,0))
```

![](Demo_files/figure-markdown_github/unnamed-chunk-5-1.png)
