## usethis namespace: start
#' @useDynLib TreeMHN, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
