require(DiagrammeR)

##' plot_tree(tree, mutations, tree_label)
##' This function plot a tree with a named list format
##' @param tree A tree with a named list format
##' @param mutations A list of mutation names corresponding to the mutation IDs
##' @param tree_label The title of the tree (Default: NULL)
##' @author Xiang Ge Luo
##' @export
plot_tree <- function(tree, mutations, tree_label = NULL) {

  graph_dot <- "
  digraph g {
  labelloc='t';
  fontname='Helvetica bold';
  fontsize=28;
  "
  if (is.null(tree_label)) {
    graph_dot <- paste(graph_dot, "label = 'Tree", tree$tree_ID, "';")
  } else {
    graph_dot <- paste(graph_dot, "label = '", tree_label, "';")
  }

  nr_nodes <- sum(tree$in_tree)
  node_idx <- c(1:length(tree$nodes))[tree$in_tree]
  node_labels <- c("Root", mutations[tree$nodes[tree$in_tree][-1]])
  for (i in c(1:nr_nodes)) {
    graph_dot <- paste(graph_dot, node_idx[i], "[label = '", node_labels[i], "'];")
  }

  parents <- tree$parents[tree$in_tree]
  for (i in c(2:nr_nodes)) {
    graph_dot <- paste(graph_dot, parents[i], "->", node_idx[i], ";")
  }

  graph_dot <- paste(graph_dot,"}")
  grViz(graph_dot)

}

