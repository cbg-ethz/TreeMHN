## usethis namespace: start
#' @useDynLib treeMHN, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
