# TreeMHN

This package implements the TreeMHN model for the joint inference of repeated evolutionary trajectories and patterns of clonal exclusivity or co-occurrence from tumor mutation trees.

## Installation

`R CMD INSTALL TreeMHN_0.1.0.tar.gz`

## Example

Please see `Demo.md` for more details.
